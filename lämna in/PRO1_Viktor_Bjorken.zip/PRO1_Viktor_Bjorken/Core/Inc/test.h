/*
 * test.h
 *
 *  Created on: Dec 6, 2023
 *      Author: viktorb
 */

#ifndef INC_TEST_H_
#define INC_TEST_H_



#endif /* INC_TEST_H_ */

void Test_program(void);

void shiftOut(uint8_t buffer[], uint8_t regs);
void toggleBlink(void);
void blink(void);
void testSwitches(void);
void testPL(void);
void ButtonTest(void);
void improvedToggleBlink(uint16_t toggleFrequency, uint16_t duration_ms,  uint8_t blinkingLED[3], uint8_t staticleds[3]);
