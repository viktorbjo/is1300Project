/*
 * traffic.h
 *
 *  Created on: Dec 7, 2023
 *      Author: viktorb
 */

#ifndef INC_TRAFFIC_H_
#define INC_TRAFFIC_H_



#endif /* INC_TRAFFIC_H_ */


void traffic(void);
